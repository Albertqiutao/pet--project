## pet backend export

已从原项目提取可运行后端代码（FastAPI）。

### 安装依赖

```bash
py -m pip install -r requirements.txt
```

### 配置（可选，启用百炼 DeepSeek）

Windows PowerShell：

```bash
setx DASHSCOPE_API_KEY "你的key"
```

重新打开终端后生效。

### 启动后端

```bash
py -m uvicorn backend.main:app --host 127.0.0.1 --port 8001
```

### 接口

- `GET /health`
- `POST /ask`

