from __future__ import annotations

import os
from typing import Any, Dict, Optional

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

from bailian_engine import BailianDeepSeekEngine
from qa_engine import PetQAEngine


class AskRequest(BaseModel):
    question: str = Field(..., min_length=1, description="用户问题/症状描述")
    pet_info: Optional[Dict[str, Any]] = Field(default=None, description="宠物档案信息（可选）")


class AskResponse(BaseModel):
    success: bool
    answer: str
    urgent: bool = False
    usage: Optional[Dict[str, Any]] = None
    source: str = Field(..., description="ai 或 local")
    matches: Optional[Any] = None


def _format_local_answer(local_result: Dict[str, Any]) -> AskResponse:
    if not local_result.get("success"):
        return AskResponse(
            success=False,
            answer=local_result.get("message", "未找到匹配答案"),
            urgent=False,
            source="local",
            matches=local_result.get("results", []),
        )

    results = local_result.get("results", []) or []
    urgent = bool(local_result.get("urgent", 0))

    lines = []
    lines.append(f"为你在知识库里找到 {len(results)} 个可能相关的情况（仅供参考）：\n")
    for i, r in enumerate(results, start=1):
        score = r.get("score", "")
        disease = r.get("disease", "未知疾病")
        lines.append(f"### {i}. {disease}（匹配度：{score}）")
        lines.append(str(r.get("answer", "")).strip())
        lines.append("")

    lines.append("⚠️ 免责声明：以上为知识库匹配结果，不能替代专业兽医诊断；如症状加重或出现抽搐/呼吸困难/尿闭等，请立即就医。")
    answer = "\n".join(lines).strip()

    return AskResponse(
        success=True,
        answer=answer,
        urgent=urgent,
        source="local",
        matches=results,
    )


app = FastAPI(title="pet-project backend", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/health")
def health() -> Dict[str, str]:
    return {"status": "ok"}


@app.on_event("startup")
def _startup() -> None:
    app.state.local_engine = PetQAEngine(csv_path="data/diseases.csv")
    app.state.ai_engine = BailianDeepSeekEngine(api_key=os.getenv("DASHSCOPE_API_KEY", "") or None)


@app.post("/ask", response_model=AskResponse)
def ask(req: AskRequest) -> AskResponse:
    ai: BailianDeepSeekEngine = app.state.ai_engine
    if getattr(ai, "api_key", ""):
        result = ai.ask(req.question, pet_info=req.pet_info)
        return AskResponse(
            success=bool(result.get("success")),
            answer=str(result.get("answer", "")),
            urgent=bool(result.get("urgent", False)),
            usage=(dict(result.get("usage")) if result.get("usage") is not None else None),
            source="ai",
        )

    local: PetQAEngine = app.state.local_engine
    local_result = local.get_answer(req.question)
    return _format_local_answer(local_result)

